from pyrogram import Client, filters
from pyrogram.types import Message

from loader import app
from functions import func
from storage.storage import Settings, VictimsEclusionRead, JsRead
from config import GlobalStack, all_iris, black_iris, victims_exclusion, victims_file

import asyncio, random, re

@app.on_message(filters.user(all_iris) & filters.regex(r'🕵️‍♂️ Служба безопасности лаборатории'), group = 101)
async def autoanswer_func(app: Client, msg: Message):
    
    entity = msg.chat.id
    
    msgt = msg.text
    msgtl = msg.text.lower()
    
    if msgt.startswith('🕵️‍♂️ Служба безопасности') and str(msg.chat.id) in Settings.autoanswer_chats and Settings.autoanswer_chats[str(msg.chat.id)]['autoanswer'] == 'True' \
    and msg.entities and len(msg.entities) >= 5:
        pass_time = False
        if Settings.autoanswer_everytime != 0:
            if not (Settings.autoanswer_num/Settings.autoanswer_everytime).is_integer():
                return
            if Settings.autoanswer_num >= Settings.autoanswer_everytime:
                Settings.autoanswer_num = 1
            Settings.autoanswer_num += 1
        if Settings.autoanswer_random:
            if random.choice([True, False]) is False:
                return
        link = func.tag_get(msg.entities[2].url)
        while GlobalStack.stop:
            await asyncio.sleep(3.5)
        GlobalStack.stop = True
        db_check = await func.check_in_db(app, link, JsRead, victims_file, get_entity = True)
        GlobalStack.stop = False
        if db_check['not_found'] == 'True':
            return
        else:
            id = list(db_check['instance'])[0]
        aotis = Settings.autoanswer_time.split(' ')
        if len(aotis) >= 2:
            await asyncio.sleep(random.randrange(int(aotis[0]), int(aotis[1])))
        else:
            await asyncio.sleep(random.randrange(int(aotis[0])))
        if id in VictimsEclusionRead.js_read or func.check_infect_time(id, JsRead.js_read):
            return
        while GlobalStack.stop:
            await asyncio.sleep(3.5)
        GlobalStack.stop = True
        
        if Settings.autoanswer_chat != 'False':
            entity = int(Settings.autoanswer_chat)
        
        temp = await app.send_message(entity, f'Заразить @{link}')
        
        await asyncio.sleep(3)
        
        async for msg_ in app.search_messages(entity, limit = 3):
            if msg_.text and msg_.id > temp.id:
                if '🤒 У вас горячка, вызванная' in msg_.text:
                    await app.send_message(entity, '!купить вакцину')
                    await asyncio.sleep(random.randrange(5, 15))
                    await app.send_message(entity, f'Заразить @{link}')
                    break
                elif msg_.text and 'Антитела смогли справиться с заражением.' in msg_.text:
                    name = re.split('(🥽 Иммунитет объекта «|» оказался стойким к вашему патогену)', msg_.text)[2]
                    if link not in VictimsEclusionRead.js_read:
                        func.victims_exclusion_append({link: {'name': name}}, victims_exclusion)
                    break
                elif msg_.text and 'Антитела смогли справиться с заражением.' in msg_.text:
                    name = re.split('(💢 Попытка заразить | провалилась...)', msg_.text)[2]
                    if link not in VictimsEclusionRead.js_read:
                        func.victims_exclusion_append({link: {'name': name}}, victims_exclusion)
                    break

        GlobalStack.stop = False