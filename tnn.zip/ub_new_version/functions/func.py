from pyrogram.types import Message
from pyrogram import Client
from sqlite3 import OperationalError
from datetime import datetime, time, timedelta

import configparser, os, json, re, asyncio, random, humanize, unicodedata, sys


def cf_read(cf: str, section: str, key: str):
    read = configparser.ConfigParser()
    
    read.read(cf)
    
    return read[section][key]

def edit_cf(cf, section, key, val):
    edit = configparser.ConfigParser()
    edit.read(cf)
    
    edit[section][key] = val
    
    with open(cf, 'w') as f:
        edit.write(f)

def create_cf(conf_file):
    
    config = configparser.ConfigParser()
    
    config.add_section('user_settings')
    
    config.set('user_settings', 'name', 'Август')
    config.set('user_settings', 'prefix', 'а')
    config.set('user_settings', 'sex', 'Она')
    config.set('user_settings', 'autoanswer_time', '15')
    config.set('user_settings', 'autoanswer_everytime', '1')
    config.set('user_settings', 'autoanswer_random', 'False')
    config.set('user_settings', 'autoanswer_chat', 'False')
    config.set('user_settings', 'dov_limited', 'True')
    config.set('user_settings', 'call_api', 'True')
    config.set('user_settings', 'autoheal', 'False')
    config.set('user_settings', 'autoheal_full', 'True')
    config.set('user_settings', 'autoheal_parted', '0')
    config.set('user_settings', 'autoheal_random', 'False')
    config.set('user_settings', 'me_inf', 'False')
    config.set('user_settings', 'infect_thanks', 'False')
    config.set('user_settings', 'infect_reaction', 'False')
    config.set('user_settings', 'auto_ex', 'False')
    config.set('user_settings', 'vampir', 'False')
    config.set('user_settings', 'auto_infecter_percent', '30')
    config.set('user_settings', 'auto_infecter_time', '3-6')
    config.set('user_settings', 'auto_infecter_sync', 'False')
    config.set('user_settings', 'auto_infecter_chat_sync', '5443619563')
    config.set('user_settings', 'auto_infecter_chat', 'False')
    config.set('user_settings', 'where_mode', 'рандом')
    config.set('user_settings', 'list_infect_delay', '3.5')
    config.set('user_settings', 'visual_victims', 'True')
    
    with open(conf_file, 'w') as f:
        config.write(f)

def create_cf_api(conf_file):
    
    config = configparser.ConfigParser()
    
    config.add_section('api')
    
    config.set('api', 'api_id', '')
    config.set('api', 'api_hash', '')
    config.set('api', 'phone_number', '')
    
    with open(conf_file, 'w') as f:
        config.write(f)

def json_append(input_data: dict, exited_db_filename):
    r = False
    if not isinstance(input_data, dict):
        raise SyntaxError('First arg must be dict')
    if not os.path.exists(exited_db_filename):
        with open(exited_db_filename, 'w') as f:
            json.dump(input_data, f, indent=4)
            r = True
    if r:
        return
    with open(exited_db_filename, 'r', encoding='utf-8') as fx:
        read_exists = json.load(fx)
    for key in input_data:
        if key in read_exists:
            read_exists.pop(key)
    read_exists.update(input_data)
    with open(exited_db_filename, 'w', encoding='utf-8') as fx:
        json.dump(read_exists, fx, indent=4)

def add_me_to_victims(app, victims_file):
    me = app.get_me()
    name = me.full_name
    victims_db = {}
    
    with open(victims_file, 'r', encoding='utf-8') as f:
        js_read = json.load(f)
    
    if str(me.id) in js_read:
        if 'username' in js_read[str(me.id)] and str(me.username) == js_read[str(me.id)]['username']:
            return
        else:
            if me.username is None and 'username' not in js_read[str(me.id)]:
                return

    if me.username is not None:
        
        victims_db[me.id] = {
            'experience': '1',
            'ot_data': '01.01.2077',
            'username': me.username,
            'name': name
        }
    else:
        
        victims_db[me.id] = {
            'experience': '1',
            'ot_data': '01.01.2077',
            'name': name
        }
    
    json_append(victims_db, victims_file)

def check_if_all_exists(f_config, trusted_f, victims_file, \
    victims_exclusion, my_illnesses_file, js_info, \
    user_config_js, f_chats_config, *, me: Client):
    
    if not os.path.exists(f_config):
        create_cf(f_config)
    trusted_data = {
        str(me.id): {
            'name': me.first_name,
            'access': {
                'lab': False, 'lvl_lab': False, 'victims': True,
                'ctimer': False, 'dov': False, 'vampir': False,
                'where_trigger': True, 'infection': True
            }
        }
    }
    if not os.path.exists(trusted_f):
        with open(trusted_f, 'w', encoding='utf-8') as fw:
            json.dump(trusted_data, fw, indent=4)
    if not os.path.exists(victims_file):
        with open(victims_file, 'w', encoding='utf-8') as fw:
            json.dump({'0000': {'username': '0000', 'experience': '0000'}}, fw, indent=4)
    if not os.path.exists(victims_exclusion):
        with open(victims_exclusion, 'w', encoding='utf-8') as f:
            json.dump({'0000': {'username': '0', 'name': None}}, f, indent=4)
    if not os.path.exists(my_illnesses_file):
        with open(my_illnesses_file, 'w', encoding='utf-8') as fw:
            json.dump({}, fw, indent=4)
    if not os.path.exists(js_info):
        
        skills = {
            'pathogen_name': None,
            'ready_pathogens': None,
            'scientist_qualification': None,
            'infectivity': None,
            'immunity': None,
            'lethality': None,
            'security_service': None,
            'bio-resources': None,
            'victims_food': None
        }
        
        with open(js_info, 'w', encoding='utf-8') as fw:
            json.dump(skills, fw, indent=4)
    if not os.path.exists(user_config_js):
        with open(user_config_js, 'w', encoding='utf-8') as fw:
            json.dump(
                {
                    'me': {'id': me.id, 'username': me.username, 'first_name': me.first_name, 'last_name': me.last_name},
                    'cycle_timers': {
                        'timer_1': None,
                        'timer_2': None,
                        'timer_3': None,
                        'timer_4': None,
                        'timer_5': None,
                        'timer_6': None,
                        'timer_7': None,
                        'timer_8': None
                    }
                }, fw, indent=4
            )
    if not os.path.exists(f_chats_config):
        
        dictionary = {
            '1': {
                'chat_title': 'False',
                'chat_exclusion': 'False',
                'autoanswer': 'False',
            }
        }
        
        with open(f_chats_config, 'w', encoding='utf-8') as fw:
            json.dump(dictionary, fw, indent=4)

    
async def get_me(app: Client):
    return app.get_me()

def ru2en(word: str) -> str:
    ru2en_dict = {
        'й': 'q', 'ф': 'a', 'я': 'z',
        'ц': 'w', 'ы': 's', 'ч': 'x',
        'у': 'e', 'в': 'd', 'с': 'c',
        'к': 'r', 'а': 'f', 'м': 'v',
        'е': 't', 'п': 'g', 'и': 'b',
        'н': 'y', 'р': 'h', 'т': 'n',
        'г': 'u', 'о': 'j', 'ь': 'm',
        'ш': 'i', 'л': 'k', 'б': ',',
        'щ': 'o', 'д': 'l', 'ю': '.',
        'з': 'p', 'ж': ';', '.': '/',
        'х': '[', 'э': "'", 'ъ': ']',
        '1': '1', '4': '4', '7': '7',
        '2': '2', '5': '5', '8': '8',
        '3': '3', '6': '6', '9': '9',
        '0': '0'
    }
    
    if len(word) == 1:
        return ru2en_dict[word.lower()]
    else:
        return ''.join([ru2en_dict[i] for i in word.lower()])


def str2bool(v):
  return v.lower() in ("true")

def up_first_word(word):
    return (word[0]).upper()+word[1:]

def json_read(filename):
    with open(filename, 'r', encoding='utf-8') as f:
        return json.load(f)

def json_write(filename, data):
    with open(filename, 'w', encoding='utf-8') as fw:
        json.dump(data, fw, indent=4)

def add_trusted(id, trusted, trusted_f, *, name = False):
    id = str(id)
    if name is False:
        name = id
    data = {
        id: {
            'name': name,
            'access': {
                'lab': False, 'lvl_lab': False, 'victims': True,
                'ctimer': False, 'dov': False, 'vampir': False,
                'where_trigger': True, 'infection': True
            }
        }
    }
    trusted.update(data)
    with open(trusted_f, 'w', encoding='utf-8') as fw:
        json.dump(trusted, fw, indent=4)

def refresh_trusted_rights(trusted_f):
    with open(trusted_f, 'r', encoding='utf-8') as fr:
        read = json.load(fr)
    data = {
        '111': {
            'name': 'name',
            'access': {
                'lab': False, 'lvl_lab': False, 'victims': True,
                'ctimer': False, 'dov': False, 'vampir': False,
                'where_trigger': True, 'infection': True
            }
        }
    }
    for key, val in data['111']['access'].items():
        for n in read.keys():
            if key not in read[n]['access'].keys():
                read[n]['access'][key] = val
    with open(trusted_f, 'w', encoding='utf-8') as fw:
        json.dump(read, fw, indent=4)

def msg_check_tattack(msg: str) -> bool:
    return [word for word in ['@', 't.me/', 'tg://openmessage?user_id='] if word in msg]

def tag_get(text: str) -> str:
    return re.search(r'(tg://openmessage(s|)\?user_id=\d+|https://t\.me/[a-zA-Zа-яА-ЯёЁ\d_.-]+|@[a-zA-Zа-яА-ЯёЁ\d_.-]+)', text)[0].replace('tg://openmessage?user_id=', '').replace('tg://openmessages?user_id=', '').replace('https://t.me/', '').replace('@', '')

# async def heal_me(app: Client, msg: Message, *, iris = False, iris_id: int):
#     while True:
#         temp = await app.send_message(iris_id, '.купить вакцину')
#         await asyncio.sleep(3)
#         await temp.delete()
#         async for msg_ in app.search_messages(iris_id, limit = 3):
#             msgt_ = msg_.text
#             if '💉 Вакцина излечила вас от горячки.' in msgt_:
#                 text = '💉 Вакцина излечила вас от горячки'
#             elif '📝 У вас нет столько био-ресурсов или ирис-коинов' in msgt_:
#                 text = '📝 У вас не хватает био-ресурсов на покупку вакцины'
#             elif '📝 У вас нет горячки. Нет необходимости покупать вакцину' in msgt_:
#                 text = '📝 У вас нет горячки, вакцина не была куплена'
#             else:
#                 text = False
#             if text:
#                 if iris:
#                     temp1 = await app.send_message(iris_id, text)
#                 else:
#                     temp1 = await app.send_message(msg.chat.id, text)
#                 await msg_.delete()
#                 await asyncio.sleep(3)
#                 await temp1.delete()
#                 return

async def my_victims_food(app: Client, msg: Message, zarlist: dict, victims_food: int, silhouette: str = False):
    
    if not isinstance(victims_food, int):
        victims_food = 0
    
    victims_top = []
    cycle_to = 50
    index = 1
    total_exp_now = 0
    total_exp_zar = 0
    total_victims = 0
    zar = list([*zarlist.items()][-50:])[::-1]
    
    # sort by index
    for n, victim in enumerate(zar, start=1):
        n_ = n
        id = victim[0]
        if 'name' in victim[1]:
            name = victim[1]['name']
        else:
            name = id
        name = less_name(name)
        exp = victim[1]['experience']
        date = victim[1]['ot_data']
        bio_entity = f'<a href="tg://openmessage?user_id={id}">{name}</a>'
        victims_top.append(f'{n}. {bio_entity} | {exp} до {date}')
        if n_ >= cycle_to:
            break
    
    # total exp now
    for i in victims_top:
        exp = i.rpartition('|')[2].split(' ')[1]
        if 'k' in exp:
            exp = float(exp.replace('k', '').replace(',', '.'))*1000
        else:
            exp = int(exp)
        total_exp_now += exp
    total_exp_now = humanize.intcomma(int(total_exp_now)).replace(",", " ")
    
    # total exp zarlist
    for i in zarlist.values():
        exp = i['experience']
        if 'k' in exp:
            exp = float(exp.replace('k', '').replace(',', '.'))*1000
        else:
            exp = int(exp)
        total_exp_zar += exp
    total_exp_zar = humanize.intcomma(int(total_exp_zar)).replace(",", " ")
    
    # total victims
    total_victims = humanize.intcomma(len(zarlist.keys())).replace(",", " ")
    
    victims_top = '\n'.join(victims_top[-100:])
    
    victims_food_real = (total_exp_zar if victims_food == 0 else victims_food)
    
    if silhouette:
        mesg = (
            f'📊 Итого: {total_victims} заражённых и {total_exp_now} био-опыта\n'
            f'🧬 Ежедневная премия: {victims_food_real} био-ресурсов'
        )
        temp = await msg.reply(mesg)
        asyncio.create_task(delete_msg([msg, temp], 16))
    else:
        mesg = (
            '🦠 Списoк больных вашим патогеном:\n'
            f'{victims_top}\n\n'
            f'📊 Итого: {total_victims} заражённых и {total_exp_now} био-опыта\n'
            f'🧬 Ежедневная премия: {victims_food_real} био-ресурсов\n'
        )
        await app.send_message(msg.chat.id, mesg)

async def illness_get(app: Client, msg: Message, illness: dict):

    illness_top = []
    cycle_to = 50
    index = 1
    total_exp_now = 0
    total_exp_zar = 0
    total_victims = 0
    
    illness = list([*illness.items()][-50:])[::-1]
    
    # sort by index
    for n, il in enumerate(illness, start=1):
        if not il:
            continue
        n_ = n
        pathogen = il[0]
        name = il[1]
        if name is not None:
            if pathogen.isdigit():
                bio_entity = f'<a href="tg://openmessage?user_id={pathogen}">{name}</a>'
            else:
                bio_entity = f'<a href="https://t.me/{pathogen}">{name}</a>'
        else:
            bio_entity = pathogen
        illness_top.append(f'{n}. {bio_entity}')# | до {date}')
        if n_ >= cycle_to:
            break
    
    illness_top = '\n'.join(illness_top)
    
    mesg = (
        '🤒 Список ваших болезней:\n'
        f'{illness_top}'
    )
    
    await app.send_message(msg.chat.id, mesg, disable_web_page_preview = True)

async def get_uid_in_bot(app: Client, username, zarlist: dict, zarlist_f, *, random_bool = True, iris_id: (int, str) = 5443619563):
    
    if '@' in username:
        username = username.split('@')[0]
    else:
        pass
    
    try_count = 0
    
    while True:
        
        if random_bool:
            if random.randrange(1, 15) == 1:
                result = await app.send_message(iris_id, random.choice(['Пинг', 'Кинг', 'Пиу', 'Бот']))
                await asyncio.sleep(random.randrange(2, 4))
                await result.delete()
        
        find = False
        no_info = False
        temp = await app.send_message(iris_id, f'.id @{username}')
        
        await asyncio.sleep(random.randrange(3000, 6000) / 1000)
        
        async for msg in app.search_messages(iris_id, limit=1):
            
            msgt = msg.text
            
            if msgt.split(' ')[0] == '🆔':
                name = re.split(r'(🆔 (пользователя|бота) | равен @\d+)', msgt)[3]
                user_id = msgt.rpartition('@')[2]
                async for msg_ in app.search_messages(iris_id, from_user = iris_id, limit=6):
                    if msg_.text == msgt:
                        await msg_.delete()
                await temp.delete()
                await msg.delete()
                find = True
                break
            elif msgt == f'.id @{username}':
                try_count += 1
                await temp.delete()
                await msg.delete()
            elif msgt == '📝 Нет информации о пользователе':
                async for msg_ in app.search_messages(iris_id, from_user = iris_id, limit=6):
                    if msg_.text == msgt:
                        await msg_.delete()
                await temp.delete()
                await msg.delete()
                no_info = True
                break
            else:
                try_count += 1
                await asyncio.sleep(random.randrange(3, 5))
                await temp.delete()
            if try_count > 7:
                return False
            elif try_count > 5:
                await asyncio.sleep(random.randrange(5, 10))
        if no_info:
            return False
        if find:
            if user_id in zarlist.js_read:
                zarlist.js_read[user_id]['username'] = username
                if not name.isdigit():
                    zarlist.js_read[user_id]['name'] = name
                with open(zarlist_f, 'w') as fw:
                    json.dump(zarlist.js_read, fw, indent = 4)
                zarlist.reload()

            
            return {'id': user_id, 'name': name}

async def check_in_db(app: Client, link: str, zarlist: dict, zarlist_f, *, exclusion: dict = None, bot_getid=True, get_entity=False, iris_id: (int, str) = 5443619563, need_name = True) -> dict:
    link = str(link)
    zar_ = 'False'
    not_found_ = 'False'
    entity_ = True
    result = None
    if not re.fullmatch(r'[\w\d]+', link):
        link = tag_get(link)
    if link.isdigit():
        # get entity
        # if get_entity is False or get_entity and entity_ is False:
        if link in zarlist.js_read:
            result = {link: zarlist.js_read[link]}
            zar_ = 'True'
        else:
            result = None
        if result is None and need_name is False:
            id = link
            result = {id: {'name': id}}
        else:
            if get_entity and result is None:
                try:
                    entity = await app.get_users(int(link))
                except:
                    entity_ = False
                else:
                    id = str(entity.id)
                    username = entity.username
                    name = entity.first_name
                    if id in zarlist.js_read:
                        result = {id: {'experience': zarlist.js_read[id]['experience'], 'ot_data': zarlist.js_read[id]['ot_data'], 'name': name}}
                        zar_ = 'True'
                    else:
                        result = {id: {'name': name}}
                    if username:
                        result[id]['username'] = username
            # check in zar & session
            if result is None:
                if exclusion and link in exclusion:
                    id = link
                    name = exclusion[link]['name']
                    result = {id: {'name': name}}
            if result is None and bot_getid is False:
                id = link
                result = {id: {'name': id}}
    else:
        # check in zar & session
        # if get_entity is False or get_entity and entity_ is False:
        zar = [(key, val) for key, val in zarlist.js_read.items() if 'username' in val and link.lower() == val['username'].lower()]
        if zar:
            result = dict(zar)
            zar_ = 'True'
        else:
            reseult = None
        # get entity
        if get_entity and result is None:
            try:
                entity = await app.get_users(str(link))
            except:
                entity_ = False
            else:
                id = str(entity.id)
                username = entity.username
                name = entity.first_name
                if id in zarlist.js_read:
                    result = {id: {'experience': zarlist.js_read[id]['experience'], 'ot_data': zarlist.js_read[id]['ot_data'], 'username': username, 'name': name}}
                    zar_ = 'True'
                else:
                    result = {id: {'username': username, 'name': name}}
                if username:
                    result[id]['username'] = username
    if result is None and bot_getid or result and bot_getid and need_name and 'name' not in result[list(result)[0]] or result and bot_getid and need_name and 'name' in result[list(result)[0]] and result[list(result)[0]]['name'] == list(result)[0]:
        result_ = await get_uid_in_bot(app, link, zarlist, zarlist_f, iris_id = iris_id, random_bool=False)
        if result_:
            id = str(result_['id'])
            if result_['id'] in zarlist.js_read:
                result = {id: zarlist.js_read[id]}
            else:
                result = {id: {'name': result_['name']}}
            result[id]['name'] = result_['name']
            if not link.isdigit():
                result[id]['username'] = link
            
            if id in zarlist.js_read:
                result[id]['experience'] = zarlist.js_read[id]['experience']
                result[id]['ot_data'] = zarlist.js_read[id]['ot_data']
                zar_ = 'True'
        else:
            not_found_ = 'True'
            result = None
    
    
    if result is None or not_found_ == 'True':
        if zar_ == 'False':
            return {'instance': result, 'zar': zar_, 'not_found': not_found_}
    else:
        id = str(list(result)[0])
        if 'name' not in result[id]:
            
            name_find = None
            async for msg in app.search_global(f'🆔 пользователя равен @{id}', limit = 1):
                name_find = re.split(r'(🆔 (пользователя|бота) | равен @\d+)', msg.text)[3]
            
            if name_find:
                name = name_find
            else:
                name = id
            result[id]['name'] = name
        else:
            name = result[id]['name']
        
        if id in zarlist.js_read:
            zar_ = 'True'
            if 'username' in result[id]:
                zarlist.js_read[id]['username'] = result[id]['username']
            if not name.isdigit():
                zarlist.js_read[id]['name'] = name
            with open(zarlist_f, 'w') as fw:
                json.dump(zarlist.js_read, fw, indent = 4)
            zarlist.reload()
        
        return {'instance': result, 'zar': zar_, 'not_found': not_found_}

async def cycle_timer(app: Client, interval: float, text: str, chat_id: int):
    while True:
        if asyncio.current_task().cancelled():
            return
        await asyncio.sleep(interval)
        await app.send_message(chat_id, text)

async def run_timer(app: Client, interval: float, text: str, chat_id: int):
    task = asyncio.create_task(cycle_timer(app, interval, text, chat_id))
    await task

def chats_config_append(input_data: dict, filename):
    with open(filename, 'r', encoding='utf-8') as fr:
        dictionary = json.load(fr)
    
    id = list(input_data.keys())[0]
    
    dictionary.update(input_data)
    
    if 'autoanswer' not in dictionary[id]:
        dictionary[id]['autoanswer'] = 'False'
    if 'auto_infecter_sync_chat' in dictionary[id]:
        for key, val in dictionary.items():
            if key != id and 'auto_infecter_sync_chat' in val and val['auto_infecter_sync_chat'] == 'True':
                dictionary[key]['auto_infecter_sync_chat'] = 'False'
    
    with open(filename, 'w', encoding='utf-8') as fw:
        json.dump(dictionary, fw, indent=4)

def check_infect_time(id, zarlist):
    id = str(id)
    if id in zarlist and 'infect_time' in zarlist[id]:
        today = datetime.now()
        z_date = datetime.strptime(zarlist[id]['infect_time'], '%d.%m.%Y %H:%M:%S')
        if z_date > today:
            return True
        else:
            return False
    else:
        return False

def json_del(file, key):
    key = str(key)
    with open(file, 'r', encoding='utf-8') as fx:
        read = json.load(fx)
    
    if key in read:
        read.pop(key)
    
    with open(file, 'w', encoding='utf-8') as fw:
        read = json.dump(read, fw, indent=4)

def db_user_check(username: str, json_data: dict) -> str:
    get_key = ''
    username = str(username)
    
    if not re.findall(r'[a-zA-Z0-9]', username):
        raise EOFError('arg should not contain @, t.me, etc.')
    
    for key, val in json_data.items():
        if 'username' in json_data[key]:
            if username == json_data[key]['username']:
                get_key = key
                for_pass = True
        else:
            pass
    if get_key != '':
        return get_key
    else:
        return False

def strip_non_ascii(string):
    return ' '.join(re.findall(r'[\d\w\s]+', string))

def less_name(name: str, ascii = True) -> str:
    orig_name = name
    name_ = strip_non_ascii(name)
    if ascii: orig_name = name_
    if len(name_) != 0:
        name = name_
    
    if len(name) > 24:
        name = ' '.join(re.findall(r'[\d\w\s]+', name))+'...'
        if len(name) > 24:
            name = f'{name[0:24]}...'
        return name
    else:
        return orig_name

def victims_exclusion_append(input_data: dict, filename):
    if not isinstance(input_data, dict):
        raise SyntaxError('First arg must be dict')
    
    with open(filename, 'r', encoding='utf-8') as fr:
        dictionary = json.load(fr)
    
    id = list(input_data.keys())[0]
    
    dictionary[id] = {'name': input_data[id]['name']}
    
    with open(filename, 'w', encoding='utf-8') as fw:
        json.dump(dictionary, fw, indent=4)

def zarlist_automation(id: str, name: str, zarlist_file: str, username=False) -> dict:
    with open(zarlist_file, 'r', encoding='utf-8') as fr:
        zarlist = json.load(fr)
    if not id.isdigit():
        return zarlist
    if id not in zarlist:
        return zarlist
    val = zarlist[id]
    if username:
        if 'username' in val and val['username'] != username:
            zarlist[id]['username'] = username
    if 'name' in val:
        if val['name'] != name:
            zarlist[id]['name'] = name
    else:
        zarlist[id]['name'] = name
    with open(zarlist_file, 'w', encoding='utf-8') as fw:
        json.dump(zarlist, fw, indent=4)
    return zarlist

async def top_victims_sort(app: Client, message: Message, zarlist, exclusion, name):
    msgt = message.text
    msgtl = message.text.lower()
    if name == msgtl.split(' ')[0]:
        msgtl = ' '.join(msgtl.split(' ')[1:])
        msgt = ' '.join(msgt.split(' ')[1:])
    msgtl = msgtl.replace('к','k')
    parts = msgt.replace('к','k').split(' ')[2:]
    victims_top = []
    cycle_to = 100
    index = 1
    total_exp = 0
    total_victims = 0
    
    if re.fullmatch(r'(топ жертв|топ жертв (0|1))', msgtl):
        zar = (dict(sorted([val for val in zarlist.items()], key=lambda item: float(item[1]['experience'].replace(',', '.').replace('k', ''))*1000 if 'k' in item[1]['experience'] else float(item[1]['experience']), reverse = True)))
    else:
        if '-' in parts[0]:
            spl = parts[0].split('-')
            num = 0
            num1 = 0
            value = 1
            if 'k' in spl[0]:
                num = spl[0].replace('k', '')
                num = float(float(num)*1000)
            else:
                num = float(''.join(spl[0]))
            if 'k' in spl[1]:
                num1 = spl[1].replace('k', '')
                num1 = float(float(num1)*1000)
            else:
                num1 = float(''.join(spl[1]))
            zar = (dict(sorted([val for val in zarlist.items()], key=lambda item: float(item[1]['experience'].replace(',', '.').replace('k', ''))*1000 if 'k' in item[1]['experience'] else float(item[1]['experience']), reverse = True)))
            zar = dict([(key, val) for key, val in zar.items() if 'k' in val['experience'] and float(val['experience'].replace('k', '').replace(',', '.'))*1000 >= num and float(val['experience'].replace('k', '').replace(',', '.'))*1000 <= num1 or 'k' not in val['experience'] and float(val['experience']) > num and float(val['experience']) <= num1])
        else:
            if parts[0] == '0':
                index = 1
            else:
                index = int(parts[0])
            cycle_to = cycle_to*index
            zar = (dict(sorted([val for val in zarlist.items()], key=lambda item: float(item[1]['experience'].replace(',', '.').replace('k', ''))*1000 if 'k' in item[1]['experience'] else float(item[1]['experience']), reverse = True)))
    
    # sort by index
    for n, victim in enumerate(zar.items(), start=1):
        n_ = n
        id = victim[0]
        if 'name' in victim[1]:
            name = victim[1]['name']
        else:
            name = id
        if id in exclusion:
            n = f'☀️ {n}'#⭐️☀️💌
        name = less_name(name)
        exp = victim[1]['experience']
        date = victim[1]['ot_data']
        bio_entity = f'<a href="tg://openmessage?user_id={id}">{name}</a>'
        victims_top.append(f'{n}. {bio_entity} | {exp} до {date}')
        if n_ >= cycle_to:
            break
    
    # total exp
    for i in victims_top[-100:]:
        exp = i.rpartition('|')[2].split(' ')[1]
        if 'k' in exp:
            exp = float(exp.replace('k', '').replace(',', '.'))*1000
        else:
            exp = int(exp)
        total_exp += exp
    total_exp = int(total_exp)
    
    # total victims
    total_victims = len(zarlist.keys())
    
    victims_top = '\n'.join(victims_top[-100:])
    
    mesg = (
        '🦠 Топ моих жертв:\n'
        f'{victims_top}\n\n'
        f'📊 Итого: {humanize.intcomma(total_exp).replace(",", " ")} био-опыта\n'
        f'Записано жертв {humanize.intcomma(total_victims).replace(",", " ")}, страниц {int(total_victims/100)}\n'
        f'Следующая страница > {index+1}'
    )
    
    await app.send_message(message.chat.id, mesg)

async def iris_calc(app: Client, message: Message, ability, fromlvl, tolvl):
    """Калькулятор"""
    if int(fromlvl) >= int(tolvl) or int(fromlvl) < 0 or int(tolvl) < 0: return

    if int(tolvl) > 1000:
        temp = await app.send_message(message.chat.id, 'Подсчет прокачки не может быть выше 1000 уровня!')
        await asyncio.sleep(12)
        return

    new_message, ability_string, price = "", "", 0
    
    for i in range(int(fromlvl), int(tolvl)):
        if [i for i in ['заразность', 'зараз', 'зз'] if i == ability]:
            price += (i + 1)**2.5
            ability_string = f'<b>💵 Улучшение с </b>{fromlvl}<b> до </b>{tolvl}<b> заразности стоит: </b>'
        elif [i for i in ['иммунитет', 'иммун', 'имун'] if i == ability]:
            price += (i + 1)**2.45
            ability_string = f'<b>💵 Улучшение с </b>{fromlvl}<b> до </b>{tolvl}<b> иммунитета стоит: </b>'
        elif [i for i in ['летальность', 'летал', 'леталка'] if i == ability]:
            price += (i + 1)**1.95
            ability_string = f'<b>💵 Улучшение с </b>{fromlvl}<b> до </b>{tolvl}<b> летальности стоит: </b>'
        elif [i for i in ['квалификация', 'квала', 'скорость'] if i == ability]:
            price += (i + 1)**2.6
            ability_string = f'<b>💵 Улучшение с </b>{fromlvl}<b> до </b>{tolvl}<b> квалификации стоит: </b>'
        elif [i for i in ['патогены', 'паты', 'патоген', 'пат'] if i == ability]:
            price += (i + 1)**2
            ability_string = f'<b>💵 Улучшение с </b>{fromlvl}<b> до </b>{tolvl}<b> патогена стоит: </b>'
        elif [i for i in ['безопасность', 'сб', 'служба'] if i == ability]:
            price += (i + 1)**2.1
            ability_string = f'<b>💵 Улучшение с </b>{fromlvl}<b> до </b>{tolvl}<b> безопасности стоит: </b>'
        else:
            return

    price = str(int(price))
    new_message = f'{ability_string}<i>{humanize.intcomma(price).replace(",", ".")}</i><b> био-ресурсов</b>'
    await app.send_message(message.chat.id, new_message)

async def iris_calc_food(app: Client, message: Message):
    msgt = message.text
    msgtl = message.text.lower()
    parts = msgt.split(' ')
    days = int(parts[2])
    msgtl = msgtl.replace('к','k')
    if 'k' in msgtl and len(parts) == 3:
        num = parts[1].replace('к', '')
        num = int((float(num)*float(days))*1000)
        profit = f'{num:,d}'.replace(',', '.')
    else:
        num = ''.join(parts[1:][:-1])
        num = int(num)*int(parts[-1:][0])
        profit = f'{num:,d}'.replace(',', '.')
    if days == 1:
        days_word = 'день'
    elif [i for i in ['2', '3', '4'] if i in str(days)]:
        days_word = 'дня'
    else:
        days_word = 'дней'
    mesg = f'<b>💵 За </b><i>{days}</i> <b>{days_word}, вы заработаете </b><i>- {profit}</i> <b>био-ресурсов.</b>'
    await app.send_message(message.chat.id, mesg)

async def iris_calc_food_lvlup(app: Client, message: Message):
    msgt = message.text
    msgtl = message.text.lower()
    parts = msgt.split(' ')
    msgtl = msgtl.replace('к','k')
    # get food num
    if 'k' in msgtl and len(parts) == 5:
        num = parts[1].replace('к', '')
        num = float(num)*1000
        ability, fromlvl, tolvl = parts[3], parts[2], parts[4]
    else:
        num = ''.join(parts[1:][0:-3])
        ability, fromlvl, tolvl = parts[-2], parts[-3], parts[-1]
    
    if int(tolvl) > 1000:
        temp = await app.send_message(message.chat.id, 'Подсчет прокачки не может быть выше 1000 уровня!')
    
    # get lvlup num
    new_message, ability_string, price = "", "", 0
    
    for i in range(int(fromlvl), int(tolvl)):
        if [i for i in ['заразность', 'зараз', 'зз'] if i == ability]:
            price += (i + 1)**2.5
            ability_string = 'зз'
        elif [i for i in ['иммунитет', 'иммун', 'имун'] if i == ability]:
            price += (i + 1)**2.45
            ability_string = 'иммун'
        elif [i for i in ['летальность', 'летал', 'леталка'] if i == ability]:
            price += (i + 1)**1.95
            ability_string = 'летал'
        elif [i for i in ['квалификация', 'квала', 'скорость'] if i == ability]:
            price += (i + 1)**2.6
            ability_string = 'квала'
        elif [i for i in ['патогены', 'паты', 'патоген', 'пат'] if i == ability]:
            price += (i + 1)**2
            ability_string = 'пат'
        elif [i for i in ['безопасность', 'сб', 'служба'] if i == ability]:
            price += (i + 1)**2.1
            ability_string = 'сб'
        else:
            return
    food_num = int(num)
    lvl_num = int(price)
    if food_num >= lvl_num:
        days = 1
    else:
        days = -int(-lvl_num/food_num // 1)
    if days == 1:
        days_word = 'день'
    elif [i for i in ['2', '3', '4'] if i in str(days)]:
        days_word = 'дня'
    else:
        days_word = 'дней'
    mesg = f'<b>💵 Вам понадобится </b><i>{days}</i> <b>{days_word}, чтобы прокачать </b><i>{ability_string}</i> <b>на</b> {tolvl} <b>уровень.</b>'
    await app.send_message(message.chat.id, mesg)

def zarlist_val_searcher(value: str, path, zarlist) -> dict:
    return dict([(key, val) for key, val in zarlist.items() if path in val and val[path] == value])

def infect_time_get() -> str:
    z_date = datetime.today() + timedelta(hours=6)
    return z_date.strftime("%d.%m.%Y %H:%M:%S")

async def bot_clear_msg(app: Client, iris_id: str):
    async for msg in app.search_messages(iris_id, from_user = iris_id, limit = 15):
        msgt = msg.text
        if re.fullmatch(r'(🆔 (пользователя|бота) .+ равен @\d+)', msgt) or msgt == '📝 Нет информации о пользователе' or msgt.split(' ') == '.id':
            await msg.delete()
        
async def delete_msg(msgs: [Message, list], delay: int) -> None:
    if isinstance(msgs, list):
        await asyncio.sleep(delay)
        for m in msgs:
            await m.delete()
    else:
        await asyncio.sleep(delay)
        await msgs.delete()

async def sleep_timer(delay: int) -> None:
    await asyncio.sleep(delay)

def restart_program():
    """Restarts the current program, with file objects and descriptors
       cleanup"""
    python = sys.executable
    os.execl(python, python, *sys.argv)


async def name_searcher_by_id(app: Client, id: [int, str]) -> (bool ,str):
    id = str(id)
    name = None
    async for msg_ in app.search_global(f'🆔 пользователя равен @{id}'):
        if msg_.entities:
            name = re.split('🆔 пользователя | равен', msg_.text)[1]
    if name is None:
        async for msg_ in app.search_global(id):
            if msg_.entities:
                if re.search(r'<a href\="tg://openmessage\?user_id={}">'.format(id), msg_.text.html):
                    line = ''.join([i for i in msg_.text.html.splitlines() if id in i])
                    temp_name = re.split(r'<a href\="tg://openmessage\?user_id={}">|</a>'.format(id), line)[1]
                    if temp_name != '':
                        name = temp_name
                        break
    return name